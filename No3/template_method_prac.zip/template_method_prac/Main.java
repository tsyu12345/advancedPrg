public class Main {
    public static void main(String[] args) {
        AbstractDisplay chDisplay = new CharDisplay('N');
        AbstractDisplay stDisplay = new StringDisplay("Nihon Univ.");
        chDisplay.display();
        stDisplay.display();
    }
}
