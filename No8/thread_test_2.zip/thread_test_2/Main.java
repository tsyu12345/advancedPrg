public class Main {
    public static void main(String[] args) throws InterruptedException {
        Counter c = new Counter(0);
        Thread thread = new Thread(c);
        thread.start();
        
        thread.join();

        System.out.println("FINISH");
    }
}
