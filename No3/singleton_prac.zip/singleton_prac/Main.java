public class Main {
    public static void main(String[] args) {
        TicketMaker tMaker1 = new TicketMaker();
        for(int i = 0; i < 5; i++) {
            System.out.println("No. " + tMaker1.getNextTicketNumber());
        }

        TicketMaker tMaker2 = new TicketMaker();
        for(int i = 0; i < 3; i++) {
            System.out.println("No. " + tMaker2.getNextTicketNumber());
        }
    }
}
