public interface Print {
    void printWeak();
    void printStrong();
}
