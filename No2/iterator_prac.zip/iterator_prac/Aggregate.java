public interface Aggregate {
    Iterator iterator();
}
