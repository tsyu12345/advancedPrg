public class Main {
    /**
     * 実行用呼び出しクラス。
     */
    public static void main(String[] args) {
        SpamCallIdentifer window = new SpamCallIdentifer("SpamCallIdentifer:スパム電話番号判定ツール");
        window.display();
    }
}
