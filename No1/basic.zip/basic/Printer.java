public class Printer {
    private String msg;
    private char mark;

    public Printer(String msg, char mark) {
        this.msg = msg;
        this.mark = mark;
    }

    public void printMsg() {
        System.out.println(mark + msg);
    }
}
