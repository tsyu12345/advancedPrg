public class Main {

    public static void main(String[] args) {
        Shared shared = new Shared();

        Thread[] threads = new Thread[3];
        for(int i = 0; i < threads.length; i++) {
            threads[i] = new Thread(new MyThread(shared));
            threads[i].start();
        }
    }

}
