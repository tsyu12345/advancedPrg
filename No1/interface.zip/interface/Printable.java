public interface Printable {
    void printMsg();
    void printStrongMsg();
}
