public class Shared {

    private int value = 0;

    public int getValue() {
        return value;
    }

}
